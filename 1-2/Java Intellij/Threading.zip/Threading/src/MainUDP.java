import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class MainUDP {
    public static void main(String[] args) {
        DatagramSocket socket= null;
        try {
            socket = new DatagramSocket(9806);
        } catch (SocketException e) {
            throw new RuntimeException(e);
        }
        System.out.println("UDP server started");

        InetAddress client1Addr=null;
        int client1Port=-1;
        InetAddress client2Addr=null;;
        int client2Port=-1;

        byte[] buf=new byte[256];
        DatagramPacket pkt=new DatagramPacket(buf, buf.length);

        while(true){
            try {
                socket.receive(pkt);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            InetAddress srcAddr=pkt.getAddress();
            int srcPort=pkt.getPort();
            if(client1Addr==null){
                client1Addr=srcAddr;
                client1Port=srcPort;
                System.out.println("Client 1: "+client1Addr+" "+client1Port);
            }
            else if(client2Addr==null && !(srcAddr.equals(client1Addr) && srcPort==client1Port)){
                client2Addr=srcAddr;
                client2Port=srcPort;
                System.out.println("Client 2: "+client2Addr+" "+client2Port);
            }

            InetAddress destAddr=null;
            int destPort=-1;
            if(srcAddr.equals(client1Addr) && srcPort==client1Port){
                destAddr=client2Addr;
                destPort=client2Port;
            }
            else if(srcAddr.equals(client2Addr) && srcPort==client2Port){
                destAddr=client1Addr;
                destPort=client2Port;
            }

            if(destAddr!=null){
                DatagramPacket forward=new DatagramPacket(pkt.getData(), pkt.getLength(), destAddr, destPort);
                try {
                    socket.send(forward);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            pkt.setLength(buf.length);
        }
    }
}
