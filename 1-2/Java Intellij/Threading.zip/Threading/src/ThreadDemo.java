public class ThreadDemo {
    public static void main(String[] args) {
        NewThread newThread = new NewThread();
        newThread.t.start();
        ExtendThread extendThread = new ExtendThread();
        extendThread.start();
        ExtendThread extendThread2 = new ExtendThread();
        extendThread2.start();
        try{
            for(int i=5;i>0;i--){
                System.out.println("Main Thread: "+i);
                Thread.sleep(1000);
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        System.out.println("Exiting Main Thread");
    }
}
